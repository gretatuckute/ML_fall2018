You may use the lists of names for any purpose, so long as credit is given
in any published work. You may also redistribute the list if you
provide the recipients with a copy of this README file. The lists are
not in the public domain (I retain the copyright on the lists) but are
freely redistributable.

If you have any additions to the lists of names, I would appreciate
receiving them.

My email address is mkant+@cs.cmu.edu.

Mark Kantrowitz
